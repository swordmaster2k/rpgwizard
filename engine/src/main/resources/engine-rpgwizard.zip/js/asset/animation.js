export class Animation {
    constructor(asset) {
        // Copy over values
        this.width = asset.width;
        this.height = asset.height;
        this.frameRate = asset.frameRate;
        this.soundEffect = asset.soundEffect;
        this.spriteSheet = asset.spriteSheet;
        this.version = asset.version;
    }
}
