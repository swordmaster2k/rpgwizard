import { Animation } from "./animation.js";
import { Map } from "./map.js";
import { Sprite } from "./sprite.js";
import { Tileset } from "./tileset.js";
export async function build(file) {
    const response = await fetch(file);
    const json = await response.json();
    if (file.endsWith(".animation")) {
        return new Animation(json);
    }
    else if (file.endsWith(".map")) {
        return new Map(json);
    }
    else if (file.endsWith(".sprite")) {
        return new Sprite(json);
    }
    else if (file.endsWith(".tileset")) {
        const dto = json;
        await loadRawAssets({ images: [dto.image] });
        return new Tileset(dto);
    }
    throw new Error(`Unknown asset type=[${file}]!`);
}
export async function loadRawAssets(assets) {
    return new Promise((resolve, reject) => {
        Crafty.load(assets, () => {
            // Assets have been loaded
            resolve();
        }, (e) => {
            // TODO: progress
        }, (e) => {
            // TODO: error
            reject(e);
        });
    });
}
