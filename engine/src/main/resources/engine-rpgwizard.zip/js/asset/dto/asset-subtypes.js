/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
export var Direction;
(function (Direction) {
    // eslint-disable-next-line no-unused-vars
    Direction["NORTH"] = "n";
    // eslint-disable-next-line no-unused-vars
    Direction["SOUTH"] = "s";
    // eslint-disable-next-line no-unused-vars
    Direction["EAST"] = "e";
    // eslint-disable-next-line no-unused-vars
    Direction["WEST"] = "w";
    // eslint-disable-next-line no-unused-vars
    Direction["NORTH_EAST"] = "ne";
    // eslint-disable-next-line no-unused-vars
    Direction["NORTH_WEST"] = "nw";
    // eslint-disable-next-line no-unused-vars
    Direction["SOUTH_EAST"] = "se";
    // eslint-disable-next-line no-unused-vars
    Direction["SOUTH_WEST"] = "sw";
    // eslint-disable-next-line no-unused-vars
    Direction["ATTACK"] = "ATTACK";
    // eslint-disable-next-line no-unused-vars
    Direction["DEFEND"] = "DEFEND";
    // eslint-disable-next-line no-unused-vars
    Direction["DIE"] = "DIE";
})(Direction || (Direction = {}));
export const StandardKeys = [
    "SOUTH", "NORTH", "EAST", "WEST", "NORTH_EAST", "NORTH_WEST",
    "SOUTH_EAST", "SOUTH_WEST", "ATTACK", "DEFEND", "SPECIAL_MOVE", "DIE",
    "REST", "SOUTH_IDLE", "NORTH_IDLE", "EAST_IDLE", "WEST_IDLE",
    "NORTH_EAST_IDLE", "NORTH_WEST_IDLE", "SOUTH_EAST_IDLE", "SOUTH_WEST_IDLE"
];
export var EventType;
(function (EventType) {
    // eslint-disable-next-line no-unused-vars
    EventType["OVERLAP"] = "overlap";
    // eslint-disable-next-line no-unused-vars
    EventType["KEYPRESS"] = "keypress";
})(EventType || (EventType = {}));
