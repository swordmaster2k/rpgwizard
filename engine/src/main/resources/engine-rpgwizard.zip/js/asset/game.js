export class Game {
    constructor(asset) {
        // Copy over values
        this.name = asset.name;
        this.viewport = asset.viewport;
        this.debug = asset.debug;
        this.version = asset.version;
    }
}
