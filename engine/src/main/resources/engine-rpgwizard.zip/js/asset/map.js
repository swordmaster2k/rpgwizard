/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
import { Core } from "../core.js"; // REFACTOR: Decouple this?
import { TilesetRenderer } from "../view/tileset-renderer.js";
export class Map {
    constructor(asset) {
        // Copy over values
        this.name = asset.name;
        this.width = asset.width;
        this.height = asset.height;
        this.tileWidth = asset.tileWidth;
        this.tileHeight = asset.tileHeight;
        this.music = asset.music;
        this.tilesets = asset.tilesets;
        this.entryScript = asset.entryScript;
        this.startLocation = asset.startLocation;
        this.layers = asset.layers;
        this.version = asset.version;
        this.layerCache = [];
    }
    replaceTile(x, y, layer, newTile) {
        const ctx = this.layerCache[layer].getContext("2d");
        ctx.putImageData(newTile, x * this.tileWidth, y * this.tileHeight);
    }
    removeTile(x, y, layer) {
        const ctx = this.layerCache[layer].getContext("2d");
        ctx.clearRect(x * this.tileWidth, y * this.tileHeight, this.tileWidth, this.tileHeight);
    }
    generateLayerCache() {
        for (const layer of this.layers) {
            const cnv = this.generateLayer(layer);
            this.layerCache.push(cnv);
        }
    }
    generateLayer(layer) {
        const cnv = document.createElement("canvas");
        cnv.width = this.width * this.tileWidth;
        cnv.height = this.height * this.tileHeight;
        const ctx = cnv.getContext("2d");
        // Render the layer tiles
        const layerTiles = layer.tiles.slice();
        if (layerTiles.length > 0) {
            for (let y = 0; y < this.height; y++) {
                for (let x = 0; x < this.width; x++) {
                    const tile = layerTiles.shift().split(":");
                    const tileSetIndex = parseInt(tile[0]);
                    const tileIndex = parseInt(tile[1]);
                    if (tileSetIndex === -1 || tileIndex === -1) {
                        continue; // Blank tile.
                    }
                    const tileset = this.tilesets[tileSetIndex]; // Render tile to board canvas
                    const renderer = new TilesetRenderer(Core.getInstance().cache.get(tileset));
                    renderer.renderTile(ctx, tileIndex, x * this.tileWidth, y * this.tileHeight);
                }
            }
        }
        return cnv;
    }
}
