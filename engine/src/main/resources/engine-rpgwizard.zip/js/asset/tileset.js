/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
import { Framework } from "../framework.js";
export class Tileset {
    constructor(asset) {
        // Copy over values
        this.tileWidth = asset.tileWidth;
        this.tileHeight = asset.tileHeight;
        this.image = asset.image;
        this.tileData = asset.tileData;
        this.version = asset.version;
        this.imageBitmap = Framework.getImage(this.image);
        this.rows = Math.floor(this.imageBitmap.height / this.tileHeight);
        this.columns = Math.floor(this.imageBitmap.width / this.tileWidth);
        this.count = this.rows * this.columns;
        this.tiles = [];
        this.prepareTiles();
    }
    getTile(index) {
        return this.tiles[index];
    }
    prepareTiles() {
        const canvas = document.createElement("canvas");
        canvas.width = this.imageBitmap.width;
        canvas.height = this.imageBitmap.height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(this.imageBitmap, 0, 0);
        for (let i = 0; i < this.count; i++) {
            // Converted 1D index to 2D cooridnates.
            const x = i % this.columns;
            const y = Math.floor(i / this.columns);
            const tile = ctx.getImageData(x * this.tileWidth, y * this.tileHeight, this.tileWidth, this.tileHeight);
            this.tiles.push(tile);
        }
    }
}
