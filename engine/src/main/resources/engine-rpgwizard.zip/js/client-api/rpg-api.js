/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
import { Core } from "../core.js";
import { Framework } from "../framework.js";
import { Draw2D } from "../view/draw-2d.js";
export class Canvas {
    constructor(canvasElement, render, x, y) {
        this.canvasElement = canvasElement;
        this.render = render;
        this.x = x;
        this.y = y;
    }
}
export class Rgba {
    constructor(r, g, b, a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }
}
export class Rpg {
    constructor(core) {
        this._core = core;
        this._mapController = core.mapController;
        this._globals = {};
        this._rgba = new Rgba(255, 255, 255, 1.0);
        this._font = "14px Arial";
        this._canvases = {};
        this._canvases.default = new Canvas(core.screen.defaultCanvas, false, 0, 0);
    }
    get canvases() {
        return this._canvases;
    }
    // ------------------------------------------------------------------------
    // Asset
    // ------------------------------------------------------------------------
    isAssetLoaded(assetId, type) {
        return Framework.isAssetLoaded(assetId, type);
    }
    async loadAssets(assets) {
        await Framework.loadAssets(assets);
    }
    removeAssets(assets) {
        Framework.removeAssets(assets);
    }
    getImage(file) {
        return Framework.getImage(file);
    }
    async loadJson(path) {
        // REFACTOR: Switch to GET request
        const response = await fetch("http://localhost:8080/engine/load", {
            method: "POST",
            credentials: "include",
            body: JSON.stringify({ path: path }),
            headers: {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        });
        return await response.json();
    }
    async saveJson(json) {
        await fetch("http://localhost:8080/engine/save", {
            method: "POST",
            credentials: "include",
            body: JSON.stringify(json),
            headers: {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        });
    }
    // ------------------------------------------------------------------------
    // Canvas
    // ------------------------------------------------------------------------
    createCanvas(canvasId, width, height) {
        const canvasElement = document.createElement("canvas");
        canvasElement.width = width;
        canvasElement.height = height;
        const canvas = new Canvas(canvasElement, false, 0, 0);
        this._canvases[canvasId] = canvas;
    }
    removeCanvas(canvasId) {
        delete this._canvases[canvasId];
    }
    render(canvasId) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            canvas.render = true;
            Framework.trigger(Framework.EventType.Invalidate);
        }
    }
    clear(canvasId) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const canvasElement = canvas.canvasElement;
            canvasElement.getContext("2d").clearRect(0, 0, canvasElement.width, canvasElement.height);
            canvas.render = true;
            Framework.trigger(Framework.EventType.Invalidate);
        }
    }
    setCanvasPosition(canvasId, x, y) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            canvas.x = x;
            canvas.y = y;
        }
    }
    // ------------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------------
    setColor(r, g, b, a) {
        this._rgba = new Rgba(r, g, b, a);
    }
    setAlpha(alpha) {
        this._rgba.a = alpha;
    }
    setFont(size, family) {
        this._font = size + "px " + family;
    }
    getPixel(canvasId, x, y) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const context = this._getDrawingContext(canvas);
            return context.getImageData(x, y, 1, 1);
        }
    }
    setPixel(canvasId, x, y) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            Draw2D.putImageData(ctx, x, y, this._rgba);
        }
    }
    drawOntoCanvas(targetId, sourceId, x, y, width, height) {
        const target = this._canvases[targetId];
        const source = this._canvases[sourceId];
        if (target && source) {
            const targetCtx = this._getDrawingContext(target);
            targetCtx.drawImage(source.canvasElement, x, y, width, height);
        }
    }
    drawCircle(canvasId, x, y, radius) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.strokeStyle = this._getStrokeStyle();
            Draw2D.drawCircle(ctx, x, y, radius);
        }
    }
    drawImage(canvasId, file, x, y, width, height, rotation) {
        const canvas = this._canvases[canvasId];
        const image = Framework.getImage(file);
        if (canvas && image) {
            const ctx = this._getDrawingContext(canvas);
            Draw2D.drawImage(ctx, image, x, y, width, height, rotation);
        }
    }
    drawImagePart(canvasId, file, srcX, srcY, srcWidth, srcHeight, destX, destY, destWidth, destHeight, rotation) {
        const canvas = this._canvases[canvasId];
        const image = Framework.getImage(file);
        if (canvas && image) {
            const ctx = this._getDrawingContext(canvas);
            Draw2D.drawImagePart(ctx, image, srcX, srcY, srcWidth, srcHeight, destX, destY, destWidth, destHeight, rotation);
        }
    }
    drawLine(canvasId, x1, y1, x2, y2, lineWidth) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.strokeStyle = this._getStrokeStyle();
            Draw2D.drawLine(ctx, x1, y1, x2, y2, lineWidth);
        }
    }
    drawRect(canvasId, x, y, width, height, lineWidth) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.strokeStyle = this._getStrokeStyle();
            Draw2D.drawRect(ctx, x, y, width, height, lineWidth);
        }
    }
    drawRoundedRect(canvasId, x, y, width, height, lineWidth, radius) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.strokeStyle = this._getStrokeStyle();
            Draw2D.drawRoundedRect(ctx, x, y, width, height, lineWidth, radius);
        }
    }
    drawText(canvasId, x, y, text) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.fillStyle = this._getFillStyle();
            Draw2D.drawText(ctx, x, y, text, this._font);
        }
    }
    fillCircle(canvasId, x, y, radius) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.fillStyle = this._getFillStyle();
            Draw2D.drawCircle(ctx, x, y, radius);
        }
    }
    fillRect(canvasId, x, y, width, height) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.fillStyle = this._getFillStyle();
            Draw2D.fillRect(ctx, x, y, width, height);
        }
    }
    fillRoundedRect(canvasId, x, y, width, height, radius) {
        const canvas = this._canvases[canvasId];
        if (canvas) {
            const ctx = this._getDrawingContext(canvas);
            ctx.fillStyle = this._getFillStyle();
            Draw2D.fillRoundedRect(ctx, x, y, width, height, radius);
        }
    }
    _getDrawingContext(canvas) {
        const ctx = canvas.canvasElement.getContext("2d");
        ctx.imageSmoothingEnabled = true;
        ctx.globalAlpha = this._rgba.a;
        return ctx;
    }
    _getStrokeStyle() {
        return "rgba(" + this._rgba.r + "," + this._rgba.g + "," + this._rgba.b + "," + this._rgba.a + ")";
    }
    _getFillStyle() {
        return this._gradient ? this._gradient : "rgba(" + this._rgba.r + "," + this._rgba.g + "," + this._rgba.b + "," + this._rgba.a + ")";
    }
    // ------------------------------------------------------------------------
    // Map
    // ------------------------------------------------------------------------
    getMap() {
        return this._mapController.mapEntity.map;
    }
    async loadMap(map) {
        await this._mapController.switchMap(map, 5, 5, 1);
    }
    async addLayerImage(imageId, layer, image) {
        if (layer < this.getMap().layers.length) {
            const mapLayer = this.getMap().layers[layer];
            mapLayer.images[imageId] = image;
        }
    }
    removeLayerImage(imageId, layer) {
        if (layer < this.getMap().layers.length) {
            const mapLayer = this.getMap().layers[layer];
            delete mapLayer.images[imageId];
        }
    }
    getTileData(x, y, layer) {
        const map = this.getMap();
        if (layer < 0 || map.layers.length < layer) {
            throw new Error("layer out of range");
        }
        const mapLayer = map.layers[layer];
        const tileIndex = (y * map.width) + x;
        if (tileIndex < 0 || mapLayer.tiles.length < tileIndex) {
            throw new Error("tile out of range");
        }
        const parts = mapLayer.tiles[tileIndex].split(":");
        if (parts[0] === "-1" || parts[1] === "-1") {
            return null; // empty tile
        }
        const tileset = this._core.cache.get(map.tilesets[parts[0]]);
        return tileset.tileData && tileset.tileData[parts[1]] ? tileset.tileData[parts[1]] : null;
    }
    replaceTile(x, y, layer, tilesetFile, tileIndex) {
        const tileset = this._core.cache.get(tilesetFile);
        const tile = tileset.getTile(tileIndex);
        this.getMap().replaceTile(x, y, layer, tile);
    }
    removeTile(x, y, layer) {
        this.getMap().removeTile(x, y, layer);
    }
    // ------------------------------------------------------------------------
    // Sprite
    // ------------------------------------------------------------------------
    getSprite(id) {
        const entity = this._mapController.findEntity(id);
        if (entity && entity.sprite) {
            return entity.sprite;
        }
        return null;
    }
    async addSprite(spriteId, layer, sprite) {
        if (layer < this.getMap().layers.length) {
            const mapLayer = this.getMap().layers[layer];
            mapLayer.sprites[spriteId] = sprite;
        }
    }
    removeSprite(spriteId) {
        const sprite = this.getSprite(spriteId);
        if (sprite) {
            delete this.getMap().layers[sprite.layer].sprites[spriteId];
        }
    }
    getSpriteLocation(spriteId, inTiles, includeOffset) {
        const sprite = this.getSprite(spriteId);
        if (sprite) {
            let x = sprite.x;
            let y = sprite.y;
            if (includeOffset) {
                x += this._mapController.mapEntity.xShift + this.getViewport()._x;
                y += this._mapController.mapEntity.yShift + this.getViewport()._y;
            }
            if (inTiles) {
                return {
                    x: Math.floor(x / this.getMap().tileWidth),
                    y: Math.floor(y / this.getMap().tileHeight),
                    layer: sprite.layer
                };
            }
            else {
                return {
                    x: x,
                    y: y,
                    layer: sprite.layer
                };
            }
        }
    }
    async animateSprite(spriteId, animationId) {
        const sprite = this.getSprite(spriteId);
        if (sprite) {
            await Framework.animateSprite(spriteId, animationId, sprite);
        }
    }
    async moveSprite(spriteId, x, y, duration) {
        const entity = this._mapController.findEntity(spriteId);
        if (entity) {
            await Framework.moveEntity(entity, x, y, duration);
        }
    }
    resetTriggers(spriteId) {
        const entity = this._mapController.findEntity(spriteId);
        if (entity && entity.sprite) {
            const sprite = entity.sprite;
            sprite.triggerEntity.resetHitChecks();
        }
    }
    setSpriteLocation(spriteId, x, y, layer, inTiles) {
        const entity = this._mapController.findEntity(spriteId);
        if (entity) {
            if (inTiles) {
                x *= this.getMap().tileWidth;
                y *= this.getMap().tileHeight;
            }
            entity.x = x;
            entity.y = y;
            entity.sprite.layer = layer;
            Framework.trigger(Framework.EventType.Invalidate);
        }
    }
    setSpriteAnimation(spriteId, animationId) {
        const sprite = this.getSprite(spriteId);
        if (sprite) {
            sprite.changeGraphics(animationId);
        }
    }
    // ------------------------------------------------------------------------
    // Geometry
    // ------------------------------------------------------------------------
    raycast(origin, direction, maxDistance) {
        // REFACTOR: Implement me
    }
    getAngleBetweenPoints(x1, y1, x2, y2) {
        return Math.atan2(y1 - y2, x1 - x2);
    }
    getDistanceBetweenPoints(x1, y1, x2, y2) {
        return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)); // Simple Pythagora's theorem.
    }
    // ------------------------------------------------------------------------
    // Global
    // ------------------------------------------------------------------------
    getGlobal(id) {
        return this._globals[id];
    }
    setGlobal(id, value) {
        this._globals[id] = value;
    }
    removeGlobal(id) {
        delete this._globals[id];
    }
    // ------------------------------------------------------------------------
    // Keyboard
    // ------------------------------------------------------------------------
    registerKeyDown(key, callback, global) {
        if (global) {
            this._core.keyDownHandlers[Framework.getKey(key)] = callback;
        }
        else {
            this._core.keyboardHandler.downHandlers[Framework.getKey(key)] = callback;
        }
    }
    unregisterKeyDown(key, global) {
        if (global) {
            delete this._core.keyDownHandlers[Framework.getKey(key)];
        }
        else {
            delete this._core.keyboardHandler.downHandlers[Framework.getKey(key)];
        }
    }
    registerKeyUp(key, callback, global) {
        if (global) {
            this._core.keyUpHandlers[Framework.getKey(key)] = callback;
        }
        else {
            this._core.keyboardHandler.upHandlers[Framework.getKey(key)] = callback;
        }
    }
    unregisterKeyUp(key, global) {
        if (global) {
            delete this._core.keyUpHandlers[Framework.getKey(key)];
        }
        else {
            delete this._core.keyboardHandler.upHandlers[Framework.getKey(key)];
        }
    }
    // ------------------------------------------------------------------------
    // Mouse
    // ------------------------------------------------------------------------
    registerMouseDown(callback, global) {
        if (global) {
            Core.getInstance().mouseDownHandler = callback;
        }
        else {
            Core.getInstance().mouseHandler.mouseDownHandler = callback;
        }
    }
    unregisterMouseDown(global) {
        if (global) {
            Core.getInstance().mouseDownHandler = null;
        }
        else {
            Core.getInstance().mouseHandler.mouseDownHandler = null;
        }
    }
    registerMouseUp(callback, global) {
        if (global) {
            Core.getInstance().mouseUpHandler = callback;
        }
        else {
            Core.getInstance().mouseHandler.mouseUpHandler = callback;
        }
    }
    unregisterMouseUp(global) {
        if (global) {
            Core.getInstance().mouseUpHandler = null;
        }
        else {
            Core.getInstance().mouseHandler.mouseUpHandler = null;
        }
    }
    registerMouseClick(callback, global) {
        if (global) {
            Core.getInstance().mouseClickHandler = callback;
        }
        else {
            Core.getInstance().mouseHandler.mouseClickHandler = callback;
        }
    }
    unregisterMouseClick(global) {
        if (global) {
            Core.getInstance().mouseClickHandler = null;
        }
        else {
            Core.getInstance().mouseHandler.mouseClickHandler = null;
        }
    }
    registerMouseDoubleClick(callback, global) {
        if (global) {
            Core.getInstance().mouseDoubleClickHandler = callback;
        }
        else {
            Core.getInstance().mouseHandler.mouseDoubleClickHandler = callback;
        }
    }
    unregisterMouseDoubleClick(global) {
        if (global) {
            Core.getInstance().mouseDoubleClickHandler = null;
        }
        else {
            Core.getInstance().mouseHandler.mouseDoubleClickHandler = null;
        }
    }
    registerMouseMove(callback, global) {
        if (global) {
            Core.getInstance().mouseMoveHandler = callback;
        }
        else {
            Core.getInstance().mouseHandler.mouseMoveHandler = callback;
        }
    }
    unregisterMouseMove(global) {
        if (global) {
            Core.getInstance().mouseMoveHandler = null;
        }
        else {
            Core.getInstance().mouseHandler.mouseMoveHandler = null;
        }
    }
    // ------------------------------------------------------------------------
    // Audio
    // ------------------------------------------------------------------------
    playAudio(id, loop, volume = 1.0) {
        const repeatCount = loop ? -1 : 1;
        Framework.playAudio(id, repeatCount, volume);
    }
    stopAudio(id) {
        Framework.stopAudio(id);
    }
    // ------------------------------------------------------------------------
    // Utility
    // ------------------------------------------------------------------------
    async sleep(duration) {
        await new Promise(resolve => setTimeout(resolve, duration));
    }
    getRandom(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    getScale() {
        return Framework.getViewport()._scale;
    }
    getViewport() {
        return Framework.getViewport();
    }
    measureText(text) {
        const ctx = this._getDrawingContext(this._canvases.default);
        ctx.font = this._font;
        return {
            width: Math.round(ctx.measureText(text).width),
            height: Math.round(parseInt(ctx.font))
        };
    }
    restart() {
        location.reload(); // Cheap way to implement game restart for the moment.
    }
    // ------------------------------------------------------------------------
    // Misc
    // ------------------------------------------------------------------------
    attachControls(id) {
        const entity = this._mapController.findEntity(id);
        if (entity) {
            entity.addComponent("CustomControls");
        }
    }
}
