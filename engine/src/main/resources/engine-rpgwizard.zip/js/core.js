/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
import { Cache } from "./asset/asset-cache.js";
import * as Factory from "./asset/asset-factory.js";
import { ScreenRenderer } from "./view/screen-renderer.js";
import { ScriptVM } from "./client-api/script-vm.js";
import { MapController } from "./map-controller.js";
import { Framework } from "./framework.js";
import { Rpg } from "./client-api/rpg-api.js";
export class Core {
    constructor() {
        // Debug flag for engine logging
        this.debugEnabled = false;
        // Setup composites
        this._mapController = new MapController();
        this._scriptVM = new ScriptVM();
        this._cache = new Cache();
        // Setup in game load
        this._screen = null;
        // Game project file.
        this._game = null;
        // Used to store state when runProgram is called.
        this._keyboardHandler = {
            downHandlers: {},
            upHandlers: {}
        };
        this._keyDownHandlers = {};
        this._keyUpHandlers = {};
        // Used to store state when runProgram is called.
        this._mouseHandler = {
            mouseDownHandler: {},
            mouseUpHandler: {},
            mouseClickHandler: {},
            mouseDoubleClickHandler: {},
            mouseMoveHandler: {}
        };
        this._mouseDownHandler = {};
        this._mouseUpHandler = {};
        this._mouseClickHandler = {};
        this._mouseDoubleClickHandler = {};
        this._mouseMoveHandler = {};
        // Engine program states.
        this._inProgram = false;
    }
    static getInstance() {
        if (!Core._instance) {
            Core._instance = new Core();
        }
        return Core._instance;
    }
    get game() {
        return this._game;
    }
    get screen() {
        return this._screen;
    }
    get cache() {
        return this._cache;
    }
    get rpg() {
        return window.rpg;
    }
    get inScript() {
        return this.scriptVM.inScript;
    }
    get mapEntity() {
        return this._mapController.mapEntity;
    }
    get scriptVM() {
        return this._scriptVM;
    }
    get mapController() {
        return this._mapController;
    }
    get keyboardHandler() {
        return this._keyboardHandler;
    }
    get keyDownHandlers() {
        return this._keyDownHandlers;
    }
    get keyUpHandlers() {
        return this._keyUpHandlers;
    }
    get mouseHandler() {
        return this._mouseHandler;
    }
    get mouseDownHandler() {
        return this._mouseDownHandler;
    }
    set mouseDownHandler(handler) {
        this._mouseDownHandler = handler;
    }
    get mouseUpHandler() {
        return this._mouseUpHandler;
    }
    set mouseUpHandler(handler) {
        this._mouseUpHandler = handler;
    }
    get mouseClickHandler() {
        return this._mouseClickHandler;
    }
    set mouseClickHandler(handler) {
        this._mouseClickHandler = handler;
    }
    get mouseDoubleClickHandler() {
        return this._mouseDoubleClickHandler;
    }
    set mouseDoubleClickHandler(handler) {
        this._mouseDoubleClickHandler = handler;
    }
    get mouseMoveHandler() {
        return this._mouseMoveHandler;
    }
    set mouseMoveHandler(handler) {
        this._mouseMoveHandler = handler;
    }
    async main(filename) {
        if (this.debugEnabled) {
            console.debug("Starting engine with filename=[%s]", filename);
        }
        this._game = await Factory.build(filename);
        // Get underlying frameworks ready
        Framework.bootstrap(this._game);
        // Setup IO & UI
        this._screen = new ScreenRenderer();
        Framework.createUI(this);
        window.rpg = new Rpg(this);
        // Run game's startup script
        try {
            console.info("Starting to run startup script...");
            await this._scriptVM.run("../../game/scripts/startup.js", this);
            console.info("Finished running startup script...");
        }
        catch (e) {
            console.error(e);
            throw new Error("Could not run startup script!");
        }
    }
}
// Asset directory paths
Core.PATH_GAME = window.location.origin + "/game";
Core.PATH_ANIMATION = Core.PATH_GAME + "/animations/";
Core.PATH_SCRIPT = Core.PATH_GAME + "/scripts/";
Core.PATH_SOUND = Core.PATH_GAME + "/sounds/"; // REFACTOR: Name AUDIO?
Core.PATH_TEXTURE = Core.PATH_GAME + "/textures/";
Core.PATH_TILESET = Core.PATH_GAME + "/tilesets/";
Core.PATH_MAP = Core.PATH_GAME + "/maps/";
Core.PATH_SPRITE = Core.PATH_GAME + "/sprites/";
