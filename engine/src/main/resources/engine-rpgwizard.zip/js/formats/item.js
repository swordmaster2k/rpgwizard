/* global PATH_ITEM, rpgwizard */

Item.prototype.constructor = Item;

function Item(filename) {
    if (rpgwizard.debugEnabled) {
        console.debug("Loading Item filename=[%s]", filename);
    }
    
    // TODO: Make the changes here that chrome suggests.
    var req = new XMLHttpRequest();
    req.open("GET", filename, false);
    req.overrideMimeType("text/plain; charset=x-user-defined");
    req.send(null);

    var item = JSON.parse(req.responseText);
    item.fileName = filename.replace(PATH_ITEM, "");
    for (var property in item) {
        this[property] = item[property];
    }
}

Item.prototype.load = function () {
    if (rpgwizard.debugEnabled) {
        console.debug("Loading Item name=[%s]", this.name);
    }

    // Return the assets that need to be loaded.
    return {"images": [this.icon]};
};

Item.prototype.setReady = function () {
    if (rpgwizard.debugEnabled) {
        console.debug("Setting ready Item name=[%s]", this.name);
    }
};
