/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
/* global rpgwizard */
import { Core } from "../core.js";
export class Keyboard {
    constructor() {
        this.downHandlers = {};
        this.upHandlers = {};
        this.entity = Crafty.e()
            .bind("KeyDown", function (e) {
            var handler = Core.getInstance().inProgram ? Core.getInstance().keyboardHandler.downHandlers[e.key] : Core.getInstance().keyDownHandlers[e.key];
            if (handler) {
                handler(e);
            }
        })
            .bind("KeyUp", function (e) {
            var handler = Core.getInstance().inProgram ? Core.getInstance().keyboardHandler.upHandlers[e.key] : Core.getInstance().keyUpHandlers[e.key];
            if (handler) {
                handler(e);
            }
        });
    }
}
