/* global rpgwizard */

function Mouse() {
    this.mouseDownHandler = null;
    this.mouseUpHandler = null;
    this.mouseClickHandler = null;
    this.mouseDoubleClickHandler = null;
    this.mouseMoveHandler = null;
}

