/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
/* global rpgwizard */
import { Core } from "../core";
import { Framework } from "../framework";
export class CanvasRenderer {
    constructor() {
        this._defaultCanvas = document.createElement("canvas");
        const viewport = Framework.getViewport();
        this._defaultCanvas.width = viewport._width;
        this._defaultCanvas.height = viewport._height;
    }
    render(ctx) {
        const viewport = Framework.getViewport();
        const x = -viewport._x;
        const y = -viewport._y;
        const canvases = Core.getInstance().rpgcodeApi.canvases;
        for (const property in canvases) {
            if (canvases.hasOwnProperty(property)) {
                const element = canvases[property];
                if (element.render) {
                    ctx.drawImage(element.canvas, x, y);
                }
            }
        }
    }
}
