export var Draw2D;
(function (Draw2D) {
    function putImageData(ctx, x, y, rgba) {
        const imageData = ctx.getImageData(x, y, 1, 1);
        imageData.data[0] = rgba.r;
        imageData.data[1] = rgba.g;
        imageData.data[2] = rgba.b;
        imageData.data[3] = rgba.a * 255;
        ctx.putImageData(imageData, x, y);
    }
    Draw2D.putImageData = putImageData;
    function drawCircle(ctx, x, y, radius) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, 2 * Math.PI);
        ctx.stroke();
    }
    Draw2D.drawCircle = drawCircle;
    function drawImage(ctx, image, x, y, width, height, rotation) {
        // rotate around center point
        x += width / 2;
        y += height / 2;
        ctx.translate(x, y);
        ctx.rotate(rotation);
        ctx.drawImage(image, -width / 2, -height / 2, width, height);
        ctx.rotate(-rotation);
        ctx.translate(-x, -y);
    }
    Draw2D.drawImage = drawImage;
    function drawImagePart(ctx, image, srcX, srcY, srcWidth, srcHeight, destX, destY, destWidth, destHeight, rotation) {
        // rotate around center point
        destX += destWidth / 2;
        destY += destHeight / 2;
        ctx.translate(destX, destY);
        ctx.rotate(rotation);
        ctx.drawImage(image, srcX, srcY, srcWidth, srcHeight, -destWidth / 2, -destHeight / 2, destWidth, destHeight);
        ctx.rotate(-rotation);
        ctx.translate(-destX, -destY);
    }
    Draw2D.drawImagePart = drawImagePart;
    function drawLine(ctx, x1, y1, x2, y2, lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }
    Draw2D.drawLine = drawLine;
    function drawRect(ctx, x, y, width, height, lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.strokeRect(x, y, width, height);
    }
    Draw2D.drawRect = drawRect;
    function drawRoundedRect(ctx, x, y, width, height, lineWidth, radius) {
        ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.stroke();
    }
    Draw2D.drawRoundedRect = drawRoundedRect;
    function drawText(ctx, x, y, text, font) {
        ctx.font = font;
        ctx.fillText(text, x, y);
    }
    Draw2D.drawText = drawText;
    function fillCircle(ctx, x, y, radius) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, 2 * Math.PI);
        ctx.fill();
    }
    Draw2D.fillCircle = fillCircle;
    function fillRect(ctx, x, y, width, height) {
        ctx.fillRect(x, y, width, height);
    }
    Draw2D.fillRect = fillRect;
    function fillRoundedRect(ctx, x, y, width, height, radius) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
        ctx.fill();
    }
    Draw2D.fillRoundedRect = fillRoundedRect;
})(Draw2D || (Draw2D = {}));
