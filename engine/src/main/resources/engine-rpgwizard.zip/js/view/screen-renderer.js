/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
import { Core } from "../core.js";
import { Framework } from "../framework.js";
export class ScreenRenderer {
    constructor() {
        this._defaultCanvas = document.createElement("canvas");
        const viewport = Framework.getViewport();
        this._defaultCanvas.width = viewport._width;
        this._defaultCanvas.height = viewport._height;
    }
    get defaultCanvas() {
        return this._defaultCanvas;
    }
    renderBoard(ctx) {
        ctx.imageSmoothingEnabled = false;
        const xShift = Core.getInstance().mapEntity.xShift;
        const yShift = Core.getInstance().mapEntity.yShift;
        const x = Core.getInstance().mapEntity.x + xShift;
        const y = Core.getInstance().mapEntity.y + yShift;
        const width = Core.getInstance().mapEntity.width;
        const height = Core.getInstance().mapEntity.height;
        if (Core.getInstance().mapEntity.show) {
            const map = Core.getInstance().mapEntity.map;
            // Draw a black background
            ctx.fillStyle = "#000000";
            ctx.fillRect(x, y, width, height);
            if (!map.layerCache.length) {
                map.generateLayerCache();
            }
            // Loop through layers.
            for (var i = 0; i < map.layers.length; i++) {
                const mapLayer = map.layers[i];
                /*
                 * Render layer tiles.
                 */
                ctx.drawImage(map.layerCache[i], 0, 0, width, height, x, y, width, height);
                /*
                 * Render layer images.
                 */
                for (const id in mapLayer.images) {
                    const image = mapLayer.images[id];
                    const imageBitmap = Framework.getImage(image.image);
                    ctx.drawImage(imageBitmap, x + image.x, y + image.y);
                }
                /*
                 * Sort sprites for depth.
                 */
                const layerSprites = this.sortSprites(mapLayer);
                /*
                 * Render sprites.
                 */
                for (const sprite of layerSprites) {
                    if (sprite && sprite.layer === i && sprite.renderReady) {
                        const frame = sprite.getActiveFrame();
                        if (frame) {
                            const x = sprite.x - (frame.width / 2) + xShift;
                            const y = sprite.y - (frame.height / 2) + yShift;
                            ctx.drawImage(frame, x, y);
                        }
                        if (Core.getInstance().game.debug.showColliders) {
                            const x = sprite.x + xShift + sprite.collider.x;
                            const y = sprite.y + yShift + sprite.collider.y;
                            this.drawCollider(ctx, sprite.collider, x, y);
                        }
                        if (Core.getInstance().game.debug.showTriggers) {
                            const x = sprite.x + xShift + sprite.trigger.x;
                            const y = sprite.y + yShift + sprite.trigger.y;
                            this.drawTrigger(ctx, sprite.trigger, x, y);
                        }
                    }
                }
                /*
                 * Render Colliders
                 */
                if (Core.getInstance().game.debug.showColliders) {
                    for (const id in mapLayer.colliders) {
                        const collider = mapLayer.colliders[id];
                        this.drawCollider(ctx, collider, xShift, yShift);
                    }
                }
                /*
                 * Render Triggers
                 */
                if (Core.getInstance().game.debug.showTriggers) {
                    for (const id in mapLayer.triggers) {
                        const trigger = mapLayer.triggers[id];
                        this.drawTrigger(ctx, trigger, xShift, yShift);
                    }
                }
            }
        }
    }
    sortSprites(layer) {
        const layerSprites = [];
        for (const id in layer.sprites) {
            const mapSprite = layer.sprites[id];
            const entity = mapSprite.entity;
            const sprite = entity.sprite;
            sprite.x = entity.x;
            sprite.y = entity.y;
            if (sprite && sprite.renderReady) {
                layerSprites.push(sprite);
            }
        }
        layerSprites.sort((a, b) => { return a.y - b.y; });
        return layerSprites;
    }
    drawCollider(ctx, collider, xShift, yShift) {
        this.drawPolygon(ctx, collider.points, xShift, yShift, "#FF0000");
    }
    drawTrigger(ctx, trigger, xShift, yShift) {
        this.drawPolygon(ctx, trigger.points, xShift, yShift, "#FFFF00");
    }
    drawPolygon(ctx, points, xShift, yShift, color) {
        let haveMoved = false;
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.0;
        ctx.beginPath();
        for (let i = 0; i < points.length - 1; i++) {
            const p1 = points[i];
            const p2 = points[i + 1];
            if (!haveMoved) {
                ctx.moveTo(p1.x + xShift, p1.y + yShift);
                haveMoved = true;
            }
            ctx.lineTo(p2.x + xShift, p2.y + yShift);
        }
        ctx.stroke();
    }
    renderUI(ctx) {
        /*
        * Render rpgcode canvases.
        */
        for (const id in Core.getInstance().rpg.canvases) {
            const canvas = Core.getInstance().rpg.canvases[id];
            if (canvas.render) {
                ctx.drawImage(canvas.canvasElement, canvas.x, canvas.y);
            }
        }
    }
}
