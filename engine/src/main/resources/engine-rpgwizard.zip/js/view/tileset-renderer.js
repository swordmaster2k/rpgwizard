/*
 * Copyright (c) 2017, rpgwizard.org, some files forked from rpgtoolkit.net <info@rpgwizard.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
export class TilesetRenderer {
    constructor(tileset) {
        this._tileset = tileset;
        this._size = {
            x: this._tileset.count * this._tileset.tileWidth,
            y: this._tileset.tileHeight
        };
    }
    render(cnv) {
        cnv = cnv || document.createElement("canvas");
        cnv.width = this._size.x;
        cnv.height = this._size.y;
        const context = cnv.getContext("2d");
        const offset = {
            x: 0,
            y: 0
        };
        // render each tile
        for (let i = 0; i < this._tileset.count; i++) {
            this.renderTile(context, i, offset.x, offset.y);
            offset.x += this._tileset.tileWidth;
        }
        return cnv;
    }
    renderTile(ctx, tileIndex, offsetX, offsetY) {
        const tile = this._tileset.getTile(tileIndex);
        if (tile) {
            ctx.putImageData(tile, offsetX, offsetY);
        }
    }
}
